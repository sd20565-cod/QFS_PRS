# Databricks notebook source
# MAGIC %run "/Workspace/Users/oumaima.idaline@external.stellantis.com/qfs_classification/qfs_sharepoint/Sharepoint_utils1"

# COMMAND ----------

#import toolbox_connected_vehicle as tcv
import pyspark.sql.functions as F
import datetime
from pyspark.sql import Window
from pyspark.sql.window import Window
from pyspark.sql import Row
from pyspark.sql.functions import *

# COMMAND ----------

scope_name = 'STL-EMEA-SCOPE_QFSSQX'
token = 'dapi57575245c04ec3e9b1098dfcef79bb66'
create_secret_scope(scope_name, token)

# COMMAND ----------

scope_name = "STL-EMEA-SCOPE_QFS"
parameters = {
     "Application Name": "STL-EMEA-LKH-LAB-SHP-QFS_PRS",
     "tenant_ID": "d852d5cd-724c-4128-8812-ffa5db3f8507",
     "Secret_Value": "45M8Q~3uLD2ladaTjD4L7G4jPJFg3Mzn8DqyucdG",
     "client_id": "020a1efc-76a1-408d-a199-d9e1630c2367",
       
}
databricks_url = "https://dbc-ea4006c8-365b.cloud.databricks.com" 
store_secrets_in_databricks(scope_name, parameters, databricks_url, token)

# COMMAND ----------

scope_name = "STL-EMEA-SCOPE_QFS"
tech_user_name = 'sd20565_qfs'
tech_user_password = 'sd20565_qfs'
store_secret_for_user(scope_name, tech_user_name, tech_user_password, databricks_url, token)


# COMMAND ----------

scope_name = 'STL-EMEA-SCOPE_QFS'  
secret_key = 'STL-EMEA-LKH-LAB-SHP-QFS_PRS' 
secret_value = '45M8Q~3uLD2ladaTjD4L7G4jPJFg3Mzn8DqyucdG' 
store_key_value_in_databricks(databricks_url, token, scope_name, secret_key, secret_value)

# COMMAND ----------

databricks_url = 'https://dbc-ea4006c8-365b.cloud.databricks.com' 
# token = 'dapia3de52187119cc9c74dbb8ff62d25ce2' 
# scope_name = 'STL-EMEA-SCOPE_VOR'  
# secret_key = 'STL-EMEA-LKH-LAB-SHP-VOR' 
# secret_value = 'Ivm8Q~WwVg-IUVfhcQ8YmkkJr3H0zfF.BgHcXair' 
# store_key_value_in_databricks(databricks_url, token, scope_name, secret_key, secret_value)